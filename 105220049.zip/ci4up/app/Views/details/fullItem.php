<?= $this->extend('layout/template'); ?>

    <?= $this->section('content'); ?>
    <main>
    <section class="py-5 text-center container">
    <div class="row py-lg-5">
        <div class="col-lg-6 col-md-8 mx-auto">
            <h1 class="fw-light">IoT Devices</h1>
            <p class="lead text-muted">Anything that has a sensor attached to it and can transmit data from one object to another or to people with the help of internet is known as an IoT device. The IoT devices include wireless sensors, software, actuators, computer devices and more.</p>
        </div>
    </div>
    </section>

    <div class="album py-5 bg-light">
    <div class="container">

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
            <div class="card shadow-sm">
            <img img class="image" width="350" height="300" src="speaker.jpg" text-align="center"></img>
            <div class="card-body">
                <h4> Aesthetic Speaker </h4>
                <p class="card-text">Take Marshall signature sound everywhere with a portable speaker and keep your music going for hours on end.</p>
                <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">Marshall Speaker</small>
                </div>
            </div>
            </div>
        </div>
        <div class="col">
            <div class="card shadow-sm">
            <img img class="image" width="350" height="300" src="arduino.jpg" text-align="center"></img>
            <div class="card-body">
                <h4> Arduino </h4>
                <p class="card-text">Arduino creating interactive objects that can take input from switches and sensors, and control physical outputs like lights, motors, or actuators. </p>
                <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">Genuino</small>
                </div>
            </div>
            </div>
        </div>
        <div class="col">
            <div class="card shadow-sm">
            <img img class="image" width="350" height="300" src="computer.jpg" text-align="center"></img>
            <div class="card-body">
                <h4> Computer </h4>
                <p class="card-text">macOS is the most advanced desktop operating system in the world. macOS Ventura makes the things you do most on Mac even better, so you can work smarter, play harder and go further. </p>
                <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">Apple Desktop</small>
                </div>
            </div>
            </div>
        </div>
        

       
        </div>
    </div>
    </div>

</main>
        <?= $this->endSection(); ?>