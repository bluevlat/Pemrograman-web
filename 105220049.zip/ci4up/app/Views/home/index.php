<?= $this->extend('layout/template'); ?>

    <?= $this->section('content'); ?>
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-light">
                        <div class="col-md-5 p-lg-5 mx-auto my-5">
                            <h1 class="display-4 fw-normal">Welcome to Monitoring with NCT IoT</h1>
                            <p class="lead fw-normal">Website application for monitoring IoT devices in an ur home. Start your monitoring with our Application.</p>
                            <a class="btn btn-outline-secondary" href="#">Buy Now</a>
                        </div>
                        <div class="product-device shadow-sm d-none d-md-block"></div>
                        <div class="product-device product-device-2 shadow-sm d-none d-md-block"></div>
                    </div>

                    <hr class="featurette-divider">
                    <div class="row featurette">
                    <div class="col-md-7">
                        <h2 class="featurette-heading fw-normal lh-1">Ours <span class="text-muted">product.</span></h2>
                        <p class="lead">our product recommends the following devices that meet our IT standards for security and compatibility with our services. Please select a device type you are interested in purchasing to expand the menu and view all available options.</p>
                    </div>
                    <div class="col-md-5">
                        <img class="image" width="450" height="300" src="arduino.jpg" role="img" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#eee"/><text x="50%" y="50%" fill="#aaa" dy=".3em"></text></img>

                    </div>
                    </div>

                    <hr class="featurette-divider">

                    <div class="row featurette">
                    <div class="col-md-7 order-md-2">
                        <h2 class="featurette-heading fw-normal lh-1">what the product? <span class="text-muted">See more.</span></h2>
                        <p class="lead">NCT offers IoT Product as the answer to those seeking electronic products that integrate modules, sensors and internet networks, with the aim of monitoring and controlling a system.The scope of this service includes planning, design, testing, to entering the stages of finishing and production.</p>
                    </div>
                    <div class="col-md-5 order-md-1">
                        <img class="image" width="450" height="300" src="c1.jpg" role="img" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#eee"/><text x="50%" y="50%" fill="#aaa" dy=".3em"></text></img>

                    </div>
                    </div>

                    <hr class="featurette-divider">

                    <div class="row featurette">
                    <div class="col-md-7">
                        <h2 class="featurette-heading fw-normal lh-1">This service <span class="text-muted">is supported by human.</span></h2>
                        <p class="lead">resources who possess experience and competence in the IoT Industry with the industry-standard production. One of NCT's achievements is to make smart meters for buildings in Canada in 2016, serving to record the date of water usage in the building. IoT Product is also used by NCT Building Management in supporting business operations. </p>
                    </div>
                    <div class="col-md-5">
                        <img img class="image" width="450" height="300" src="c2.jpg" role="img" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#eee"/><text x="50%" y="50%" fill="#aaa" dy=".3em"></text></img>

                    </div>
                    </div>

                    <hr class="featurette-divider">

                    <!-- /END THE FEATURETTES -->

                </div><!-- /.container -->


                <!-- FOOTER -->
                <footer class="container">
                    <p class="float-end"><a href="#">Back to top</a></p>
                    <p>&copy; 2022 NCT Company, Inc. &middot; </p>
                </footer>
                </main>
                </div>
                </div>
            </div>
        </div>



        <?= $this->endSection(); ?>