<?= $this->extend('layout/template'); ?>

    <?= $this->section('content'); ?>
    <!DOCTYPE html>
    <html>
    <style type="text/css">
        .button a {
            color: #ffffff;
            text-decoration: none;
        }
    </style>
        <div class="container">
            <div class="row">
                <div class="col">
                    <h1 class="mt-2">Daftar Barang</h1>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Gambar</th>
                                <th scope="col">Device Name</th>
                                <th scope="col">Merk</th>
                                <th scope="col">Jumlah</th>
                                <th scope="col">Status</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td>
                                    <img img class="image" width="300" height="150" src="arduino.jpg"></img>
                                </td>
                                <td>Arduino</td>
                                <td>Genuino</td>
                                <td>127</td>
                                <td>1</td>
                                <td class="button">
                                    <button type="button" class="btn btn-success"><a class="nav-link" href="/device-details/Arduino">Details</a></button>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">2</th>
                                <td>
                                    <img img class="image" width="300" height="200" src="speaker.jpg"></img>
                                </td>
                                <td>Speaker</td>
                                <td>Marshall</td>
                                <td>7</td>
                                <td>1</td>
                                <td class="button">
                                    <button type="button" class="btn btn-success"><a class="nav-link" href="/device-details/SmartCCTV">Details</a></button>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">3</th>
                                <td>
                                    <img img class="image" width="300" height="200" src="computer.jpg"></img>
                                </td>
                                <td>Computer (PC)</td>
                                <td>Apple</td>
                                <td>18</td>
                                <td>1</td>
                                <td class="button">
                                    <button type="button" class="btn btn-success"><a class="nav-link" href="/device-details/Computer(PC)">Details</a></button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
</html>
<?= $this->endSection(); ?>